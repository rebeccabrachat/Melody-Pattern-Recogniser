The MusicXML files in folder 'jianpu' are meant
to be translated to LilyPond with:

  xml2ly -jianpu FILENAME.xml

and the resulting file can be turned into a graphical score by:

  lilypond FILENAME.ly
